package BackEnd;



public class Gestor extends Colaborador {

    public Gestor(String user, String password, String nome, String morada, String telefone, String email) {
      super(user, password, nome, morada, telefone, email);

    }

}
